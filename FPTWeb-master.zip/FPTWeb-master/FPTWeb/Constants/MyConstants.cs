﻿namespace FPTWeb.Constants
{
    public enum Roles
    {
        Admin,
        User
    }
    public class MyConstants
    {
    }
}
